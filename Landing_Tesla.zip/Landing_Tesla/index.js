var things = require('./things');
console.log(things.some_value);
console.log(things.array_counter([1,2,3,4,5,6,7]));
console.log(things.multiply([4,2]));
